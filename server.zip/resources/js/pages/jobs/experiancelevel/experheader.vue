<template>
  <!-- Page Header -->
          <div class="page-header">
            <div class="row align-items-center">
              <div class="col">
                <h3 class="page-title">Experience Level</h3>
                <ul class="breadcrumb">
                  <li class="breadcrumb-item"><router-link to="/index">Dashboard</router-link></li>
                  <li class="breadcrumb-item">Jobs</li>
                  <li class="breadcrumb-item active">Experience Level</li>
                </ul>
              </div>
              <div class="col-auto float-end ms-auto">
                <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#add_employee" class="btn add-btn"> Add Experience Level</a>
              </div>
            </div>
          </div>
          <!-- /Page Header -->
</template>
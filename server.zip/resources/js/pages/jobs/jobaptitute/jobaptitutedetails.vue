<template>
<div class="card">
                  <div class="card-body">
                    <p>Name : <b>John Richerd</b></p>
                    <p>Code : <b>#1245</b></p>
                    <p>Job Type : <b>UI Development</b></p>
                  </div>
                </div>
</template>
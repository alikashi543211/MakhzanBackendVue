 <template>
 <!-- Logo -->
                <div class="header-left">
                    <router-link to="/index" class="logo">
            <img src="../../assets/img/logo.png" width="40" height="40" alt="">
          </router-link>
                </div>
        <!-- /Logo -->
        </template>